package modele;

public enum Action {
	
	Monter,
	Descendre,
	Avance, //vers la fin
	Recule, //vers le debut
	Tirer,
	Braquer,
	Nothing
}
